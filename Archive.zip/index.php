<!-- =========[ BN1FB 2016 Project v.1.0 ]============ --><?php include "time_since.php"; ?><?php include "tweet_parse.php"; ?><!DOCTYPE html><html lang="en" >  <head>    <meta charset="utf-8">    <meta http-equiv="X-UA-Compatible" content="IE=edge">    <meta name="viewport" content="width=device-width, initial-scale=1">    <title>BN1FB 2016 Project</title>	<!--Core CSS -->  	<link rel="stylesheet" href="css/animate.css">    <link href="css/bootstrap.min.css" rel="stylesheet">	 <!-- Custom styles for this template -->    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet">    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->    <!--[if lt IE 9]>      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>    <![endif]-->    <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">    <!-- <script type="text/javascript" src="ig.js"></script> -->		<!-- <script type="text/javascript" src="js/main.js"></script> -->  </head>  <body >  <!-- Header Section Start -->	<header id="header_part top">		<div class="header_part" id="head">			<div class="overlay">				<div class="start_part">
						<div class="container">							<div class="row">								<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">									<div class="row">										<!-- Logo Start -->										<div class="site_logo">											<a href="#" title=""><img src="images/logo.png" alt="" title=""/></a>										</div>										<!-- Logo End-->										<!-- Site Title start-->
										<div class="site_title">											<h1>Coming soon.</h1>
											<p>Ini adalah website penampung aspirasi masyarakat terkait pelaksanaan Pemilukada Gubernur Kepulauan Bangka Belitung, ,<br>
                      Website ini bukanlah website resmi KPU , Lembaga, Instansi, kelompok atau Perseorangan tertentu, dan merupakan sumbangsih saya <br>
                      <strong><a href="http://instagram.com/veris_juniardi">Veris Juniardi</a> &amp; Kawan - Kawan</strong><br>
                       sebagai putra daerah asli Provinsi Bangka Belitung untuk menampung dan mempublish aspirasi masyarakat Bangka Belitung yang tertuang di Sosial Media (Twiter &amp; Instagram) dengan menggunakan Hashtag BN1_2016 (#BN1_2016) terkait #kritik dan #saran, serta #pelanggaran Pemilukada Gubernur dan Wakil Gubernur Bangka Belitung 2016 melalui sosial media</p>
										</div>										<!-- Site Title end-->										<!-- Countdown start --
										<div class="countdown wow bounceInUp">											<div class="defaultCountdown"></div>										</div>										<!-- Countdown end-->
                <!-- <div class="row">
								<div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
									<div class="welcome_part wow fadeInLeft">
										<div class="welcome_icon">
											<i class="fa fa-file-image-o fa-4x"></i>
										</div>
										<h2>AWESOME DESIGN</h2>
										<p>Curabitur blandit tempus ptitor. Cum socielerisque nisl cons commodo cursus magna, vel scelerisque nisl onsec teet. </p>
									</div>
								</div>
							<div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
								<div class="welcome_part wow fadeInUp">
									<div class="welcome_icon">
										<i class="fa fa-life-ring fa-4x"></i>
									</div>
									<h2>AWESOME DESIGN</h2>
									<p>Curabitur blandit tempus ptitor. Cum socielerisque nisl cons commodo cursus magna, vel scelerisque nisl onsec teet. </p>
								</div>
							</div>
							<div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
								<div class="welcome_part wow fadeInDown">
									<div class="welcome_icon">
										<i class="fa fa-briefcase fa-4x"></i>
									</div>
									<h2>AWESOME DESIGN</h2>
									<p>Curabitur blandit tempus ptitor. Cum socielerisque nisl cons commodo cursus magna, vel scelerisque nisl onsec teet. </p>
								</div>
							</div>
							<div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
								<div class="welcome_part wow fadeInRight">
									<div class="welcome_icon">
										<i class="fa fa-trophy fa-4x"></i>
									</div>
									<h2>AWESOME DESIGN</h2>
									<p>Curabitur blandit tempus ptitor. Cum socielerisque nisl cons commodo cursus magna, vel scelerisque nisl onsec teet. </p>
								</div>
							</div>
						</div> -->

									</div>								</div>							</div>						</div>				</div>
				<!-- Menu Start -->				<div class="menu_area" id="stick_menu">					<div class="container">						<div class="row">							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">								<nav class="navbar navbar-default" role="navigation">									<div class="container-fluid">										<div class="collapse navbar-collapse mainnavmenu" id="bs-example-navbar-collapse-1">										<div id="menu-center">											<ul class="nav navbar-nav navbar-right mainnav">												<li><a href="#header_part" >Start</a></li>												<li><a href="#welcome_section">Welcome</a></li>												<li><a href="result/">Result</a></li>												<li><a href="#donasi">Donasi</a></li>											</ul>
										</div>										</div>									</div>								</nav>							</div>						</div>					</div>				</div>				<!-- Menu End-->			</div>		</div>
	</header>  <!-- Header Section End -->
  <!-- About Section Start -->
	<section id="welcome_section">		<div class="welcome_section">			<div class="container">				<div class="row">					<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">						<div class="row">
						<!-- About text start -->							<div class="section-title">								<h2>Welcome to our BN1FB 2016 Project</h2>								<p>Ini adalah proyek <i>non profit oriented</i> yang bertujuan sebagai wadah penampung aspirasi masyarakat Bangka Belitung <br>yang tersebar di Sosial Media                  (<i class="fa fa-twitter"> </i> Twitter &amp; <i class="fa fa-instagram"> </i> Instagram dengan menggunakan fungsi Tagar atau <i>Hashtag(#)</i></p>							</div>						<!-- About text end -->
						</div>						<!-- About service part start-->
						<div class="row">								<div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">									<div class="welcome_part wow fadeInLeft">										<div class="welcome_icon">											<i class="fa fa-file-image-o fa-4x"></i>										</div>										<h2>Dokumentasi</h2>										<p>Setiap Tweet &amp; Foto yang anda kirim dan upload di sosial media anda dengan menggunakan <b class="up">#BN1_BABEL2017</b>,                      secara otomatis akan terdokumentasi di database dan website kami. </p>									</div>								</div>							<div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">								<div class="welcome_part wow fadeInUp">									<div class="welcome_icon">										<i class="fa fa-file-text-o fa-4x"></i>									</div>									<h2>Tabulasi Data</h2>									<p>Data yang terekam di database kami akan kami pakai atau gunakan untuk disampaikan langsung sebagai rekomendasi anda baik itu <b class="up">#KRITIK</b>                     maupun <b class="up">#SARAN</b>,                    sebagai bahan acuan program pemerintah dan calon Terpilih nantinya. </p>								</div>							</div>							<div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">								<div class="welcome_part wow fadeInDown">									<div class="welcome_icon">										<i class="fa fa-pie-chart fa-4x"></i>									</div>									<h2>Segmentasi Data</h2>									<p>Gunakan <b class="up">#KRITIK</b> sebagai Hashtag tambahan <b class="up">#BN1_BABEL2017</b> jika postingan sosmed anda berupa kritikan kepada paslon tertentu dan                   Gunakan <b class="up">#SARAN</b> sebagai Hashtag tambahan <b class="up">#BN1_BABEL2017</b> jika postingan sosmed anda berupa saran dan masukan terkait pelaksanaan Pilkada atau Pasangan Calon Tertentu</p>								</div>							</div>							<div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">								<div class="welcome_part wow fadeInRight">									<div class="welcome_icon">										<i class="fa fa-eye fa-4x"></i>									</div>									<h2>Whistle Blower</h2>									<p>Gunakan <b class="up">#PELANGGARAN</b> sebagai Hashtag tambahan setelah <b class="up">#BN1_BABEL2017</b> jika postingan terkait pelanggaran Pemilu pada timses dan atau pasangan calon tertentu.</p>								</div>							</div>						</div>
						<!-- About service part end-->
					</div>				</div>			</div>		</div>	</section>  <!-- About Section End -->
<section id="welcome_section">
<div class="container">
  <div class="section-title text-center">
		<div class="welcome_icon">
    <i class="fa fa-twitter fa-4x"></i>
   </div>
    <h2>Timeline Twitter</h2>
  </div>
  <ul class="mad-list">
    <?php
    foreach ($t->statuses as $key => $s) {
    ?>
    <li class="timeline">
      <div class="mad-list-icon">
      <img src="<?php echo $s->user->profile_image_url; ?> " alt="" class="img img-circle"/>
        <!-- <span class="mad-icon-40" style="background-image:url(https://i.stack.imgur.com/1ZIkv.jpg?s=64&g=1)"></span> -->
      </div>
      <div class="mad-list-text">
        <p>
          <b><?php echo $s->user->name; ?></b>&mdash;
          <small class="text-muted"><i class="glyphicon glyphicon-time"> </i> <?php echo time_since(strtotime($s->created_at)); ?></small>
          <br/>
          <?php echo $s->text; ?>
          <br/>
          <small class="pull-right">
            <strong class="sos"><i class="fa fa-user"> </i> <?php echo $s->user->friends_count; ?> </strong>
            <strong class="sos"><i class="fa fa-commenting-o"> </i> <?php echo $s->user->statuses_count; ?> </strong>
            <strong class="sos"><i class="fa fa-retweet"> </i> <?php echo $s->retweet_count; ?> </strong>
          </small>
        </p>
      </div>
    </li>
    <br>
  <?php
        } ?>
  </ul>
</div>
</section>


<div id="instagram">
</div>

  <!-- Subscriber Section Start -->
	<section id="donasi">		<div class="email_subscribe_section" >			<div class="container">				<div class="row">					<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">					<!-- Email Subscriber text start-->
						<div class="section-title">							<h2>DONATION</h2>							<p>untuk mendukung kegiatan ini, terkait pemeliharaan sistem dan perbaikan kami menerima Donasi dari siapapun <br>                bersifat <strong><i>Sukarela &amp; Tidak Mengikat</i></strong><br>                haraf melakukan konfirmasi donasi melalui :<br>                e-mail  : <a style="color:#000" href="mailto:veris.juniardi@gmail.com?subject=feedback">veris.juniardi@gmail.com</a>, atau <br>                SMS/WAG : +6282281469926. <br>                Terima Kasih              </p>						</div>					<!-- Email Subscriber text end-->
						<div class="email_subscribe_form_part wow zoomIn">						<!-- Email Subscribe Form start -->								<input type="text" class="form-control email_input_box text-center" placeholder="BANK BRI a/n. Veris Juniardi" disabled /> <br>                No.Rek : <h4 class="form-control email_input_box text-center" >   2020-01-002385-50-9    </h4>						<!-- Email Subscribe Form End -->						<div id="show_subscriber_msg"></div>						</div>					</div>				</div>			</div>		</div>
	</section>  <!-- Subscriber Section End -->   <!--Core js-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>    <script src="js/bootstrap.min.js"></script>    <script src="js/jquery.smooth-scroll.js"></script>    <script src="js/wow.min.js"></script>    <script src="js/jquery.nicescroll.min.js"></script>	<!--common script init for all pages-->    <script src="js/script.js"></script>  </body></html>
