<?php
echo "<h1>";
echo "Halaman LAPORAN : TABEL ,CHART, & PRINT/CETAK REKAP ASPIRASI =KRITIK=SARAN=PELAPORAN";
echo "</h1>";

 ?>
